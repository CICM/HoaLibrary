/*
 // Copyright (c) 2012-2013 Eliott Paris & Pierre Guillot, CICM, Universite Paris 8.
 // For information on usage and redistribution, and for a DISCLAIMER OF ALL
 // WARRANTIES, see the file, "LICENSE.txt," in this distribution.
 */

/**
 @file      hoa.3d.map~.cpp
 @name      hoa.3d.map~
 @realname  hoa.3d.map~
 @type      object
 @module    hoa
 @author    Julien Colafrancesco, Pierre Guillot, Eliott Paris.
 
 @digest
 A 3d ambisonic multisource spatializer
 
 @description
 <o>hoa.3d.map~</o> is a tool that encodes several sources in the spherical harmonics domain, it's easy to use and work with the GUI <o>hoa.3d.map</o>. With a single source's configuration you can manage coordinates at signal rate
 
 @discussion
 <o>hoa.3d.map~</o> is a tool that encodes several sources in the spherical harmonics domain, it's easy to use and work with the GUI <o>hoa.3d.map</o>. With a single source's configuration you can manage coordinates at signal rate
 
 @category ambisonics, hoa objects, audio, MSP
 
 @seealso hoa.2d.map~, hoa.3d.map, hoa.3d.encoder~, hoa.3d.decoder~, hoa.3d.optim~, hoa.3d.scope~, hoa.3d.wider~
 */

// TODO : LINE DE AZIMUT ELEVATION ET RADIUS

#include "../Hoa3D.max.h"
#include "MapPolarLines3D.h"

typedef struct _hoa_map 
{
	t_pxobject      f_ob;
    Hoa3D::Map*     f_map;
	
	MapPolarLines3D*  f_lines;
    float			f_lines_vector[128];
	double			f_ramp;
	int             f_mode;
	
	double*         f_sig_ins;
    double*         f_sig_outs;
} t_hoa_map;


void *hoa_map_new(t_symbol *s, long argc, t_atom *argv);
void hoa_map_free(t_hoa_map *x);
void hoa_map_assist(t_hoa_map *x, void *b, long m, long a, char *s);

void hoa_map_float(t_hoa_map *x, double f);
void hoa_map_int(t_hoa_map *x, long n);
void hoa_map_list(t_hoa_map *x, t_symbol* s, long argc, t_atom* argv);

void hoa_map_dsp64(t_hoa_map *x, t_object *dsp64, short *count, double samplerate, long maxvectorsize, long flags);

void hoa_map_perform64_multisources(t_hoa_map *x, t_object *dsp64, double **ins, long numins, double **outs, long numouts, long sampleframes, long flags, void *userparam);

void hoa_map_perform64(t_hoa_map *x, t_object *dsp64, double **ins, long numins, double **outs, long numouts, long sampleframes, long flags, void *userparam);

void hoa_map_perform64_azimuth(t_hoa_map *x, t_object *dsp64, double **ins, long numins, double **outs, long numouts, long sampleframes, long flags, void *userparam);
void hoa_map_perform64_elevation(t_hoa_map *x, t_object *dsp64, double **ins, long numins, double **outs, long numouts, long sampleframes, long flags, void *userparam);
void hoa_map_perform64_distance(t_hoa_map *x, t_object *dsp64, double **ins, long numins, double **outs, long numouts, long sampleframes, long flags, void *userparam);

void hoa_map_perform64_azimuth_elevation(t_hoa_map *x, t_object *dsp64, double **ins, long numins, double **outs, long numouts, long sampleframes, long flags, void *userparam);
void hoa_map_perform64_azimuth_distance(t_hoa_map *x, t_object *dsp64, double **ins, long numins, double **outs, long numouts, long sampleframes, long flags, void *userparam);
void hoa_map_perform64_elevation_distance(t_hoa_map *x, t_object *dsp64, double **ins, long numins, double **outs, long numouts, long sampleframes, long flags, void *userparam);

void hoa_map_perform64_azimuth_elevation_distance(t_hoa_map *x, t_object *dsp64, double **ins, long numins, double **outs, long numouts, long sampleframes, long flags, void *userparam);

t_max_err ramp_set(t_hoa_map *x, t_object *attr, long argc, t_atom *argv);

t_hoa_err hoa_getinfos(t_hoa_map* x, t_hoa_boxinfos* boxinfos);
t_class *hoa_map_class;
    

int C74_EXPORT main(void)
{	

	t_class *c;
	
	c = class_new("hoa.3d.map~", (method)hoa_map_new, (method)hoa_map_free, (long)sizeof(t_hoa_map), 0L, A_GIMME, 0);
	
	hoa_initclass(c, (method)hoa_getinfos);
	
	// @method float @digest Set single source coordinate with messages depending on the mode.
	// @description Set single source coordinate with messages depending on the mode.
	// @marg 0 @name coord @optional 0 @type float
	class_addmethod(c, (method)hoa_map_float,		"float",	A_FLOAT, 0);
	
	// @method int @digest Set single source coordinate with messages depending on the mode.
	// @description Set single source coordinate with messages depending on the mode.
	// @marg 0 @name coord @optional 0 @type int
	class_addmethod(c, (method)hoa_map_int,         "int",		A_LONG, 0);
	
	// @method list @digest Send source messages (coordinates and mute state).
	// @description Send source messages like coordinates and mute state. The list must be formatted like this : source-index input-mode azimuth elevation radius to set source positions or like this : source-index 'mute' mute-state to set the mute state of a source.
	// marg 0 @name source-index @optional 0 @type int
	// marg 1 @name input-mode/mute @optional 0 @type symbol
	// marg 2 @name coord-1/mute-state @optional 0 @type float/int
	// marg 3 @name coord-2 @optional 0 @type float
	// marg 4 @name coord-3 @optional 0 @type float
    class_addmethod(c, (method)hoa_map_list,        "list",		A_GIMME, 0);
	
	// @method signal @digest Sources signals to encode.
	// @description If you have a single source, the first signal inlet is for the source to encode, the three other ones are to control source position at signal rate. If you have more than one source to spatialize, all of the inputs represent a signal to encode and coordonates are given with messages.
	class_addmethod(c, (method)hoa_map_dsp64,		"dsp64",	A_CANT, 0);
	class_addmethod(c, (method)hoa_map_assist,      "assist",	A_CANT, 0);
	
	CLASS_ATTR_DOUBLE           (c, "ramp", 0, t_hoa_map, f_ramp);
	CLASS_ATTR_CATEGORY			(c, "ramp", 0, "Behavior");
	CLASS_ATTR_LABEL			(c, "ramp", 0, "Ramp Time (ms)");
	CLASS_ATTR_ORDER			(c, "ramp", 0, "2");
	CLASS_ATTR_ACCESSORS		(c, "ramp", NULL, ramp_set);
	// @description The ramp time in milliseconds.
	
	class_dspinit(c);
	class_register(CLASS_BOX, c);	
	hoa_map_class = c;
	return 0;
}

void *hoa_map_new(t_symbol *s, long argc, t_atom *argv)
{
	// @arg 0 @name ambisonic-order @optional 0 @type int @digest The ambisonic order of decomposition
	// @description First argument is the ambisonic order of decomposition.
	
	// @arg 1 @name number-of-sources @optional 0 @type int @digest The number of sources
	// @description Second argument is the number of sources to spatialize.
	// If there is a single source, <o>hoa.2d.map~</o> object owns 4 inlets, the first one correspond to the signal to encode, the three other ones can be used to control source position at control or signal rate. If you have more than one source to spatialize, the number of signal inlets will be equal to the number of sources to encode, and coordinates will be given with list messages.
	
	t_hoa_map *x = NULL;
	int	order = 1;
    int numberOfSources = 1;
    x = (t_hoa_map *)object_alloc(hoa_map_class);
	if (x)
	{		
		if(atom_gettype(argv) == A_LONG)
			order = atom_getlong(argv);
        if(argc > 1 && atom_gettype(argv+1) == A_LONG)
            numberOfSources = atom_getlong(argv+1);

		x->f_map = new Hoa3D::Map(order, numberOfSources);
		if(x->f_map->getNumberOfSources() == 1)
            dsp_setup((t_pxobject *)x, 4);
        else
            dsp_setup((t_pxobject *)x, x->f_map->getNumberOfSources());
		
		for (int i = 0; i < x->f_map->getNumberOfHarmonics(); i++)
			outlet_new(x, "signal");
        
        if(x->f_map->getNumberOfSources() == 1)
            x->f_sig_ins    =  new double[4 * SYS_MAXBLKSIZE];
        else
            x->f_sig_ins    =  new double[x->f_map->getNumberOfSources() * SYS_MAXBLKSIZE];
        x->f_sig_outs   =  new double[x->f_map->getNumberOfHarmonics() * SYS_MAXBLKSIZE];
	}
    
	return (x);
}

void hoa_map_float(t_hoa_map *x, double f)
{
    if(x->f_map->getNumberOfSources() == 1)
    {
        if(proxy_getinlet((t_object *)x) == 1)
        {
            x->f_map->setAzimuth(0, f);
        }
        else if(proxy_getinlet((t_object *)x) == 2)
        {
            x->f_map->setElevation(0, f);
        }
        else if(proxy_getinlet((t_object *)x) == 3)
        {
            x->f_map->setRadius(0, f);
        }
    }
    
}

void hoa_map_int(t_hoa_map *x, long n)
{
	if(x->f_map->getNumberOfSources() == 1)
    {
        if(proxy_getinlet((t_object *)x) == 1)
        {
            x->f_map->setAzimuth(0, n);
        }
        else if(proxy_getinlet((t_object *)x) == 2)
        {
            x->f_map->setElevation(0, n);
        }
        else if(proxy_getinlet((t_object *)x) == 3)
        {
            x->f_map->setRadius(0, n);
        }
    }
}

t_max_err ramp_set(t_hoa_map *x, t_object *attr, long argc, t_atom *argv)
{
    if(argc && argv)
    {
        if(atom_gettype(argv) == A_LONG || atom_gettype(argv) == A_FLOAT)
        {
            x->f_ramp = clip_min(atom_getfloat(argv), 0);
            x->f_lines->setRamp(x->f_ramp / 1000. * sys_getsr());
        }
    }
    
    return MAX_ERR_NONE;
}

void hoa_map_list(t_hoa_map *x, t_symbol* s, long argc, t_atom* argv)
{
    if(argc && argv && atom_gettype(argv) == A_LONG)
    {
        int index = atom_getlong(argv);
        if(index < 0)
            return;
        if(index > x->f_map->getNumberOfSources() - 1)
            return;
        if(argc > 1 && atom_gettype(argv+1) == A_FLOAT)
            x->f_map->setAzimuth(index, atom_getfloat(argv+1));
        if(argc > 2 && atom_gettype(argv+2) == A_FLOAT)
            x->f_map->setElevation(index, atom_getfloat(argv+2));
        if(argc > 3 && atom_gettype(argv+3) == A_FLOAT)
            x->f_map->setRadius(index, atom_getfloat(argv+3));
    }
}

void hoa_map_dsp64(t_hoa_map *x, t_object *dsp64, short *count, double samplerate, long maxvectorsize, long flags)
{
    if(x->f_map->getNumberOfSources() == 1)
    {
        if(!count[1] && !count[2] && !count[3])
            object_method(dsp64, gensym("dsp_add64"), x, hoa_map_perform64, 0, NULL);
        else if(count[1] && !count[2] && !count[3])
            object_method(dsp64, gensym("dsp_add64"), x, hoa_map_perform64_azimuth, 0, NULL);
        else if(!count[1] && count[2] && !count[3])
            object_method(dsp64, gensym("dsp_add64"), x, hoa_map_perform64_elevation, 0, NULL);
        else if(!count[1] && !count[2] && count[3])
            object_method(dsp64, gensym("dsp_add64"), x, hoa_map_perform64_distance, 0, NULL);
        else if(count[1] && count[2] && !count[3])
            object_method(dsp64, gensym("dsp_add64"), x, hoa_map_perform64_azimuth_elevation, 0, NULL);
        else if(count[1] && !count[2] && count[3])
            object_method(dsp64, gensym("dsp_add64"), x, hoa_map_perform64_azimuth_distance, 0, NULL);
        else if(!count[1] && count[2] && count[3])
            object_method(dsp64, gensym("dsp_add64"), x, hoa_map_perform64_elevation_distance, 0, NULL);
        else
            object_method(dsp64, gensym("dsp_add64"), x, hoa_map_perform64_azimuth_elevation_distance, 0, NULL);
    }
    else
    {
        object_method(dsp64, gensym("dsp_add64"), x, hoa_map_perform64_multisources, 0, NULL);
    }
}

void hoa_map_perform64_multisources(t_hoa_map *x, t_object *dsp64, double **ins, long numins, double **outs, long numouts, long sampleframes, long flags, void *userparam)
{
    for(int i = 0; i < numins; i++)
    {
        cblas_dcopy(sampleframes, ins[i], 1, x->f_sig_ins+i, numins);
    }
    for(int i = 0; i < sampleframes; i++)
    {
        x->f_map->process(x->f_sig_ins + numins * i, x->f_sig_outs + numouts * i);
    }
    for(int i = 0; i < numouts; i++)
    {
        cblas_dcopy(sampleframes, x->f_sig_outs+i, numouts, outs[i], 1);
    }
}

void hoa_map_perform64(t_hoa_map *x, t_object *dsp64, double **ins, long numins, double **outs, long numouts, long sampleframes, long flags, void *userparam)
{
	for(int i = 0; i < sampleframes; i++)
    {
        x->f_map->process(&ins[0][i], x->f_sig_outs + numouts * i);
    }
    for(int i = 0; i < numouts; i++)
    {
        cblas_dcopy(sampleframes, x->f_sig_outs+i, numouts, outs[i], 1);
    }
}

void hoa_map_perform64_azimuth(t_hoa_map *x, t_object *dsp64, double **ins, long numins, double **outs, long numouts, long sampleframes, long flags, void *userparam)
{
    for(int i = 0; i < sampleframes; i++)
    {
        x->f_map->setAzimuth(0, ins[1][i]);
        x->f_map->process(&ins[0][i], x->f_sig_outs + numouts * i);
    }
    for(int i = 0; i < numouts; i++)
    {
        cblas_dcopy(sampleframes, x->f_sig_outs+i, numouts, outs[i], 1);
    }
}

void hoa_map_perform64_elevation(t_hoa_map *x, t_object *dsp64, double **ins, long numins, double **outs, long numouts, long sampleframes, long flags, void *userparam)
{
	for(int i = 0; i < sampleframes; i++)
    {
        x->f_map->setElevation(0, ins[2][i]);
        x->f_map->process(&ins[0][i], x->f_sig_outs + numouts * i);
    }
    for(int i = 0; i < numouts; i++)
    {
        cblas_dcopy(sampleframes, x->f_sig_outs+i, numouts, outs[i], 1);
    }
}

void hoa_map_perform64_distance(t_hoa_map *x, t_object *dsp64, double **ins, long numins, double **outs, long numouts, long sampleframes, long flags, void *userparam)
{
	for(int i = 0; i < sampleframes; i++)
    {
        x->f_map->setRadius(0, ins[3][i]);
        x->f_map->process(&ins[0][i], x->f_sig_outs + numouts * i);
    }
    for(int i = 0; i < numouts; i++)
    {
        cblas_dcopy(sampleframes, x->f_sig_outs+i, numouts, outs[i], 1);
    }
}

void hoa_map_perform64_azimuth_elevation(t_hoa_map *x, t_object *dsp64, double **ins, long numins, double **outs, long numouts, long sampleframes, long flags, void *userparam)
{
    for(int i = 0; i < sampleframes; i++)
    {
        x->f_map->setAzimuth(0, ins[1][i]);
        x->f_map->setElevation(0, ins[2][i]);
        x->f_map->process(&ins[0][i], x->f_sig_outs + numouts * i);
    }
    for(int i = 0; i < numouts; i++)
    {
        cblas_dcopy(sampleframes, x->f_sig_outs+i, numouts, outs[i], 1);
    }
}

void hoa_map_perform64_azimuth_distance(t_hoa_map *x, t_object *dsp64, double **ins, long numins, double **outs, long numouts, long sampleframes, long flags, void *userparam)
{
    for(int i = 0; i < sampleframes; i++)
    {
        x->f_map->setAzimuth(0, ins[1][i]);
        x->f_map->setRadius(0, ins[3][i]);
        x->f_map->process(&ins[0][i], x->f_sig_outs + numouts * i);
    }
    for(int i = 0; i < numouts; i++)
    {
        cblas_dcopy(sampleframes, x->f_sig_outs+i, numouts, outs[i], 1);
    }
}

void hoa_map_perform64_elevation_distance(t_hoa_map *x, t_object *dsp64, double **ins, long numins, double **outs, long numouts, long sampleframes, long flags, void *userparam)
{
    for(int i = 0; i < sampleframes; i++)
    {
        x->f_map->setElevation(0, ins[2][i]);
        x->f_map->setRadius(0, ins[3][i]);
        x->f_map->process(&ins[0][i], x->f_sig_outs + numouts * i);
    }
    for(int i = 0; i < numouts; i++)
    {
        cblas_dcopy(sampleframes, x->f_sig_outs+i, numouts, outs[i], 1);
    }
}

void hoa_map_perform64_azimuth_elevation_distance(t_hoa_map *x, t_object *dsp64, double **ins, long numins, double **outs, long numouts, long sampleframes, long flags, void *userparam)
{
    for(int i = 0; i < sampleframes; i++)
    {
        x->f_map->setAzimuth(0, ins[1][i]);
        x->f_map->setElevation(0, ins[2][i]);
        x->f_map->setRadius(0, ins[3][i]);
        x->f_map->process(&ins[0][i], x->f_sig_outs + numouts * i);
    }
    for(int i = 0; i < numouts; i++)
    {
        cblas_dcopy(sampleframes, x->f_sig_outs+i, numouts, outs[i], 1);
    }
}


t_hoa_err hoa_getinfos(t_hoa_map* x, t_hoa_boxinfos* boxinfos)
{
	boxinfos->object_type = HOA_OBJECT_3D;
	boxinfos->autoconnect_inputs = x->f_map->getNumberOfSources();
	boxinfos->autoconnect_outputs = x->f_map->getNumberOfHarmonics();
	boxinfos->autoconnect_inputs_type = HOA_CONNECT_TYPE_STANDARD;
	boxinfos->autoconnect_outputs_type = HOA_CONNECT_TYPE_AMBISONICS;
	return HOA_ERR_NONE;
}

void hoa_map_assist(t_hoa_map *x, void *b, long m, long a, char *s)
{
    if(m == ASSIST_INLET)
	{
        if(x->f_map->getNumberOfSources() == 1)
        {
            if(a == 0)
                sprintf(s,"(Signal) Input");
            else if(a == 1)
                sprintf(s,"(Signal or float) Azimuth");
            else if(a == 2)
                sprintf(s,"(Signal or float) Elevation");
            else
                sprintf(s,"(Signal or float) Distance");
        }
        else
        {
            if(a == 0)
                sprintf(s,"(Signal and messages) Input 0 and sources coordinates");
            else
                sprintf(s,"(Signal or float) Input %ld", a);
        }
        
	}
	else 
	{
		sprintf(s,"(Signal) %s", x->f_map->getHarmonicName(a).c_str());
	}
}


void hoa_map_free(t_hoa_map *x) 
{
	dsp_free((t_pxobject *)x);
	delete x->f_map;
    delete [] x->f_sig_ins;
    delete [] x->f_sig_outs;
}

